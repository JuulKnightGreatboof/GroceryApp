package com.example.groceryapp;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;
import android.content.Intent;
import android.graphics.drawable.AnimationDrawable;
import android.os.Build;
import android.os.Bundle;
import android.util.SparseBooleanArray;
import android.view.View;
import android.view.WindowManager;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import androidx.annotation.NonNull;

import android.widget.ListView;
import android.widget.Toast;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.ValueEventListener;

import com.google.firebase.database.FirebaseDatabase;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.UUID;

import io.paperdb.Paper;

public class CreateListActivity extends AppCompatActivity {
    private ArrayList<String> people = new ArrayList<String>();
    private ListView list;
    private EditText inviteEmail;
    private EditText enterListName;
    private Button createListbutton;
    private Button historyButton;
    private Button invite, cancel, accept, delete;
    private String theList, listID, personName;
    private AlertDialog.Builder dialogBuilder;
    private AlertDialog dialog;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_create_list);

        enterListName = findViewById(R.id.enterListName);
        inviteEmail = findViewById(R.id.inviteEmail);
        createListbutton = findViewById(R.id.createListButton);
        invite = findViewById(R.id.inviteButton);
        listID = UUID.randomUUID().toString();
        historyButton = findViewById(R.id.historyButton);

        createListbutton.setOnClickListener(new View.OnClickListener() {
            @RequiresApi(api = Build.VERSION_CODES.N)
            @Override
            public void onClick(View view) {
                theList = enterListName.getText().toString();
                FirebaseDatabase.getInstance().getReference().child("Lists").addValueEventListener(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot snapshot) {
                        if(snapshot.child(theList).exists()){
                            enterListName.getText().clear();
                            Toast.makeText(CreateListActivity.this, "List already exists!", Toast.LENGTH_SHORT).show();
                        }
                        else{
                            if(theList.isEmpty() == false) {
                                HashMap<String, Object> List1 = new HashMap<>();
                                List1.put(FirebaseAuth.getInstance().getCurrentUser().getUid(), "Person 0");
                                FirebaseDatabase.getInstance().getReference("Lists").child(theList).child("People").child("Accepted").updateChildren(List1);
                                DatabaseReference ref = FirebaseDatabase.getInstance().getReference();
                                ref.child("Lists").child(theList).addListenerForSingleValueEvent(new ValueEventListener() {
                                    @Override
                                    public void onDataChange(@NonNull DataSnapshot snapshot) {
                                        if(!snapshot.child("uniqueID").exists()){
                                            for (int i = 0; i < people.size(); i++) {
                                                List1.put(people.get(i), "Person " + (i + 1));
                                            }
                                            List1.remove(FirebaseAuth.getInstance().getCurrentUser().getUid(), "Person 0");
                                            FirebaseDatabase.getInstance().getReference("Lists").child(theList).child("People").child("Pending").updateChildren(List1);
                                            FirebaseDatabase.getInstance().getReference("Lists").child(theList).child("List Name").setValue(theList);
                                            FirebaseDatabase.getInstance().getReference("Lists").child(theList).child("List Name Online")
                                                    .setValue(theList + " (USER AT STORE!)");
                                            FirebaseDatabase.getInstance().getReference("Lists").child(theList).child("uniqueID").setValue(listID);
                                            openMainActivity();
                                        }
                                        else{
                                            for (int i = 0; i < people.size(); i++) {
                                                List1.put(people.get(i), "Person " + (i + 1));
                                            }
                                            List1.remove(FirebaseAuth.getInstance().getCurrentUser().getUid(), "Person 0");
                                            FirebaseDatabase.getInstance().getReference("Lists").child(theList).child("People").child("Pending").updateChildren(List1);
                                            FirebaseDatabase.getInstance().getReference("Lists").child(theList).child("List Name").setValue(theList);
                                            FirebaseDatabase.getInstance().getReference("Lists").child(theList).child("List Name Online")
                                                    .setValue(theList + " (USER AT STORE!)");
                                            FirebaseDatabase.getInstance().getReference("Lists").child(theList).child("uniqueID").setValue(listID);
                                            openMainActivity();
                                        }
                                    }

                                    @Override
                                    public void onCancelled(@NonNull DatabaseError error) {

                                    }
                                });
                            }
                            else {
                                Toast.makeText(CreateListActivity.this, "Please Enter a Name for the List", Toast.LENGTH_SHORT).show();
                            }
                        }
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError error) {

                    }
                });

            }
        });
        invite.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                theList = enterListName.getText().toString();
                String thePerson = inviteEmail.getText().toString();
                FirebaseDatabase.getInstance().getReference("Users").addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot snapshot) {
                        if(snapshot.getRef().toString().equals(thePerson)){
                            personName = snapshot.child(thePerson).child("name").getValue().toString();
                        }
                        if(people.contains(thePerson) || thePerson.equals(FirebaseAuth.getInstance().getCurrentUser().getUid())){
                            Toast.makeText(CreateListActivity.this, personName+" has already been added!", Toast.LENGTH_SHORT).show();
                            inviteEmail.getText().clear();
                        }
                        else if(snapshot.hasChild(thePerson) && thePerson.isEmpty() == false){
                            people.add(thePerson);
                            FirebaseDatabase.getInstance().getReference().child("Users").child(thePerson).child("Pending").child(listID).setValue(theList);
                            inviteEmail.getText().clear();
                            Toast.makeText(CreateListActivity.this, personName+" has been added!", Toast.LENGTH_SHORT).show();
                        }
                        else{
                            inviteEmail.getText().clear();
                            Toast.makeText(CreateListActivity.this, "User does not exist!", Toast.LENGTH_SHORT).show();
                        }
                    }


                    @Override
                    public void onCancelled(@NonNull DatabaseError error) {

                    }
                });
            }

        });
        historyButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                createFromHistory();
            }
        });
    }

    //Create a list from history
    public void createFromHistory() {
        dialogBuilder = new AlertDialog.Builder(this);
        final View userView = getLayoutInflater().inflate(R.layout.history_popup, null);
        cancel = (Button) userView.findViewById(R.id.cancelButton2);
        accept = (Button) userView.findViewById(R.id.createHistory);
        delete = (Button) userView.findViewById(R.id.deleteHistory);
        list = (ListView) userView.findViewById(R.id.historyList);
        dialogBuilder.setView(userView);
        dialog = dialogBuilder.create();
        dialog.show();

        HashMap<String, Object> List1 = new HashMap<>();
        ArrayList<String> historyList = new ArrayList<>();
        ArrayAdapter adapter = new ArrayAdapter<String>(this,android.R.layout.simple_list_item_multiple_choice, historyList);
        list.setAdapter(adapter);
        DatabaseReference reference = FirebaseDatabase.getInstance().getReference();
        DatabaseReference ref2 = reference.child("Users").child(FirebaseAuth.getInstance().getCurrentUser().getUid()).child("History");
        System.out.println(ref2.toString());
        ref2.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                for (DataSnapshot snapshot2 : snapshot.getChildren()) {
                    if(snapshot2.exists()){
                        historyList.add(snapshot2.getKey());
                    }
                }
                adapter.notifyDataSetChanged();
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });
        accept.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                SparseBooleanArray checked = list.getCheckedItemPositions();
                int historyCount = list.getCount();
                for(int w = historyCount - 1; w >= 0; w--) {
                    if(checked.get(w)) {
                        String checkHistory = historyList.get(w);
                        adapter.remove(checkHistory);
                        ref2.addListenerForSingleValueEvent(new ValueEventListener() {
                            @Override
                            public void onDataChange(@NonNull DataSnapshot snapshot) {
                                HashMap<String, Object> newList = new HashMap<>();
                                newList.put(FirebaseAuth.getInstance().getCurrentUser().getUid(), "Person 0");
                                FirebaseDatabase.getInstance().getReference("Lists").child(checkHistory).child("People").child("Accepted").updateChildren(newList);
                                DatabaseReference ref = FirebaseDatabase.getInstance().getReference();
                                openMainActivity();
                            }

                            @Override
                            public void onCancelled(@NonNull DatabaseError error) {

                            }
                        });
                    }
                }
            }
        });
        delete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                SparseBooleanArray checked = list.getCheckedItemPositions();
                int historyCount = list.getCount();
                for(int w = historyCount - 1; w >= 0; w--) {
                    if(checked.get(w)) {
                        String historyDelete = historyList.get(w);
                        adapter.remove(historyDelete);
                        ref2.addListenerForSingleValueEvent(new ValueEventListener() {
                            @Override
                            public void onDataChange(@NonNull DataSnapshot snapshot) {
                                DatabaseReference reference = FirebaseDatabase.getInstance().getReference().child("Users").child(FirebaseAuth.getInstance().getCurrentUser().getUid()).child("History").child(historyDelete);
                                reference.removeValue();
                                dialog.dismiss();
                            }

                            @Override
                            public void onCancelled(@NonNull DatabaseError error) {

                            }
                        });
                    }
                }
            }
        });
        cancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                dialog.dismiss();
            }
        });
    }

    public void openMainActivity() {
        Intent intent = new Intent(this, MainActivity.class);
        startActivity(intent);
    }

    private void addList(View view) {
    }
}
