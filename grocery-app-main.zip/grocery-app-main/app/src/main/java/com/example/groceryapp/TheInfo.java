package com.example.groceryapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;

import java.util.ArrayList;

public class TheInfo extends AppCompatActivity {

    private ImageView tutScreen, backward, forward;
    private int index;
    private Button back;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_the_info);

        Intent x = getIntent();
        String data = x.getStringExtra("tut");

        tutScreen = findViewById(R.id.tutScreen);
        backward = findViewById(R.id.backward);
        forward = findViewById(R.id.forward);
        back = findViewById(R.id.back3);

        ArrayList<Integer> drawables = new ArrayList<>();

        if(data == "0"){
            drawables.add(R.drawable._step1_1);
            drawables.add(R.drawable._step1_2);
            drawables.add(R.drawable._step1_3);
            drawables.add(R.drawable._step1_4);
            drawables.add(R.drawable._step1_5);
            drawables.add(R.drawable._step1_6);
        } else if(data == "1"){
            drawables.add(R.drawable._step2_1);
            drawables.add(R.drawable._step2_2);
        } else if(data == "2"){
            drawables.add(R.drawable._step3_1);
            drawables.add(R.drawable._step3_2);
        } else if(data == "3"){
            drawables.add(R.drawable._step4_1);
            drawables.add(R.drawable._step4_2);
            drawables.add(R.drawable._step4_3);
            drawables.add(R.drawable._step4_4);
        } else if(data == "4"){
            drawables.add(R.drawable._step5_1);
            drawables.add(R.drawable._step5_2);
            drawables.add(R.drawable._step5_3);
            drawables.add(R.drawable._step5_4);
        } else if(data == "5"){
            drawables.add(R.drawable._step6_1);
            drawables.add(R.drawable._step6_2);
        }

        tutScreen.setImageResource(drawables.get(0));
        backward.setVisibility(View.INVISIBLE);

        index = 0;

        forward.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(index + 1 < drawables.size()){
                    backward.setVisibility(View.VISIBLE);
                    index += 1;
                    tutScreen.setImageResource(drawables.get(index));
                    if(index + 1 == drawables.size()){
                        forward.setVisibility(View.INVISIBLE);
                    }
                }
            }
        });

        backward.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(index - 1 >= 0){
                    forward.setVisibility(View.VISIBLE);
                    index -= 1;
                    tutScreen.setImageResource(drawables.get(index));
                    if(index == 0){
                        backward.setVisibility(View.INVISIBLE);
                    }
                }
            }
        });

        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                drawables.clear();
                startActivity(new Intent(TheInfo.this, InfoPage.class));
            }
        });
    }
}