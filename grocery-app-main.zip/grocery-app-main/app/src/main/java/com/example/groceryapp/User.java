package com.example.groceryapp;

import java.util.*;

public class User {
    //private member variables
    private String name;
    private String email;
    //private String uniqueID;
    private ArrayList<String> listReferences;

    //constructor
    public User(String n, String e) {
        name = n;
        email = e;
        listReferences = new ArrayList<String>(); //holds references to a created list from database
        //uniqueID = UUID.randomUUID().toString(); //random unique id generator
    }

    //getter methods
    public String getName() {
        return name;
    }
    public String getEmail() {
        return email;
    }
    /*public String getUniqueID() {
        return uniqueID;
    }*/

    //add current user to a list (via ID)
    public void receiveInviteToList(String id) {
        listReferences.add(id);
    }
}
