package com.example.groceryapp;

import java.util.*;

public class MyList {
    //private member variables
    private String uniqueListID;
    private ArrayList<Item> itemList;

    //constructor
    public MyList() {
        uniqueListID = UUID.randomUUID().toString();
        itemList = new ArrayList<Item>();
    }

    //getter method for unique list ID
    public String getUniqueListID() {
        return uniqueListID;
    }

    //add and "remove" method for items lists
    public void addItem(String item) {
        itemList.add(new Item(item));
    }
    public void removeItem(String item) {
        for(int i = 0; i < itemList.size(); i++) {
            if(itemList.get(i).getItemName().equals(item))
                itemList.get(i).setAsBought();
        }
    }
}

