package com.example.groceryapp;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.drawerlayout.widget.DrawerLayout;

import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.icu.text.IDNA;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.util.SparseBooleanArray;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.material.navigation.NavigationView;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.PrimitiveIterator;

import io.paperdb.Paper;

public class MainActivity extends AppCompatActivity {

    private ListView listView, list;
    private TextView status;
    private ImageButton button;
    private ImageView shopGreyIcon, copyUID, logout, info;
    private Button cancel, accept;
    private DrawerLayout drawerLayout;
    private NavigationView navigationView;
    private AlertDialog.Builder dialogBuilder;
    private AlertDialog dialog;
    private int itemCount, w, i;
    private String yourID;
    //SparseBooleanArray mCheckStates;

    //displays user's invitation list
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.nav_activity_main);
        status = findViewById(R.id.status);
        shopGreyIcon = findViewById(R.id.shopGreyIcon);
        listView = findViewById(R.id.listView);
        logout = findViewById(R.id.logout);
        drawerLayout = findViewById(R.id.drawer_layout);
        navigationView = findViewById(R.id.nav_view);
        copyUID = findViewById(R.id.imageView4);
        info = findViewById(R.id.imageView2);
        yourID = FirebaseAuth.getInstance().getCurrentUser().getUid();

        SharedPreferences preferences = getSharedPreferences("Status", MODE_PRIVATE);
        String yourStatus = preferences.getString("status", "");
        if(yourStatus.equals("Status: OFFLINE")){
            status.setText("Status: OFFLINE");
            shopGreyIcon.setImageResource(R.drawable.shopgrey);
        } else if (yourStatus.equals("Status: ONLINE")){
            status.setText("Status: ONLINE");
            shopGreyIcon.setImageResource(R.drawable.shopgreen);
        }

        info.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(MainActivity.this, InfoPage.class));
            }
        });

        navigationView.setNavigationItemSelectedListener(new NavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                switch ( item.getItemId()){
                    case R.id.nav_invites:
                        checkInvites();
                        return true;
                }
                return false;
            }
        });

        //button that marks a list as "online" indicating they are at the location
        shopGreyIcon.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(status.getText().equals("Status: OFFLINE")){
                    FirebaseDatabase.getInstance().getReference("Lists").addListenerForSingleValueEvent(new ValueEventListener() {
                        @Override
                        public void onDataChange(@NonNull DataSnapshot snapshot) {
                            for (DataSnapshot snapshot2 : snapshot.getChildren()) {
                                if (snapshot2.child("People").child("Accepted").child(yourID).exists()) {
                                    String nameOfList = snapshot2.child("List Name").getValue().toString();
                                    FirebaseDatabase.getInstance().getReference("Lists").child(nameOfList).child("Online").child(yourID).setValue(yourID);
                                }
                            }
                        }

                        @Override
                        public void onCancelled(@NonNull DatabaseError error) {

                        }
                    });
                    SharedPreferences preferences = getSharedPreferences("Status", MODE_PRIVATE);
                    SharedPreferences.Editor editor = preferences.edit();
                    editor.putString("status", "Status: ONLINE");
                    editor.putString("shopGreyIcon", "R.drawable.shopgreen");
                    editor.apply();
                    status.setText("Status: ONLINE");
                    shopGreyIcon.setImageResource(R.drawable.shopgreen);
                } else {
                    FirebaseDatabase.getInstance().getReference("Lists").addListenerForSingleValueEvent(new ValueEventListener() {
                        @Override
                        public void onDataChange(@NonNull DataSnapshot snapshot) {
                            for (DataSnapshot snapshot2 : snapshot.getChildren()) {
                                if (snapshot2.child("People").child("Accepted").child(yourID).exists()) {
                                    String nameOfList = snapshot2.child("List Name").getValue().toString();
                                    FirebaseDatabase.getInstance().getReference("Lists").child(nameOfList).child("Online").child(yourID).removeValue();
                                }
                            }
                        }

                        @Override
                        public void onCancelled(@NonNull DatabaseError error) {

                        }
                    });
                    SharedPreferences preferences = getSharedPreferences("Status", MODE_PRIVATE);
                    SharedPreferences.Editor editor = preferences.edit();
                    editor.putString("status", "Status: OFFLINE");
                    editor.putString("shopGreyIcon", "R.drawable.shopgrey");
                    editor.apply();
                    status.setText("Status: OFFLINE");
                    shopGreyIcon.setImageResource(R.drawable.shopgrey);
                }
            }
        });

        //allows the user to copy their uniqueID to their clipboard
        copyUID.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                copyUID.setImageResource(R.drawable.touched);
                ClipboardManager clipboard =  (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
                ClipData clip = ClipData.newPlainText("EditText", yourID);
                clipboard.setPrimaryClip(clip);
                Toast.makeText(MainActivity.this, "User ID copied to Clipboard!", Toast.LENGTH_SHORT).show();

                Handler handler = new Handler();
                handler.postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        copyUID.setImageResource(R.drawable.touchthis);
                    }
                }, 250);
            }
        });

        //button to log the user out of the app
        logout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);
                builder.setMessage("Are you sure you want to Log Out?").setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        SharedPreferences preferences = getSharedPreferences("Status", MODE_PRIVATE);
                        SharedPreferences.Editor editor = preferences.edit();
                        editor.putString("status", "Status: OFFLINE");
                        editor.putString("shopGreyIcon", "R.drawable.shopgrey");
                        editor.apply();
                        status.setText("Status: OFFLINE");
                        shopGreyIcon.setImageResource(R.drawable.shopgrey);
                        FirebaseDatabase.getInstance().getReference("Lists").addListenerForSingleValueEvent(new ValueEventListener() {
                            @Override
                            public void onDataChange(@NonNull DataSnapshot snapshot) {
                                for (DataSnapshot snapshot2 : snapshot.getChildren()) {
                                    if (snapshot2.child("People").child("Accepted").child(yourID).exists()) {
                                        String nameOfList = snapshot2.child("List Name").getValue().toString();
                                        FirebaseDatabase.getInstance().getReference("Lists").child(nameOfList).child("Online").child(yourID).removeValue();
                                    }
                                }
                            }

                            @Override
                            public void onCancelled(@NonNull DatabaseError error) {

                            }
                        });
                        Paper.book().destroy();
                        Toast.makeText(MainActivity.this, "Logout Successful", Toast.LENGTH_SHORT).show();
                        Intent intent = new Intent(MainActivity.this, StartActivity.class);
                        startActivity(intent);
                    }
                }).setNegativeButton("No", null);
                AlertDialog alert = builder.create();
                alert.show();
            }
        });

        //button to switch to createListActivity
        button = (ImageButton) findViewById(R.id.imageButton);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                openCreateListActivity();
            }
        });

        //displays all the user's lists
        ArrayList<String> list = new ArrayList<>();
        ArrayAdapter adapter = new ArrayAdapter<String>(this,android.R.layout.simple_list_item_1, list);
        listView.setAdapter(adapter);
        DatabaseReference reference = FirebaseDatabase.getInstance().getReference();
        DatabaseReference listName = reference.child("Lists");
        listName.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if(dataSnapshot.exists())
                    list.clear();
                for (DataSnapshot snapshot : dataSnapshot.getChildren()) {
                    if (snapshot.child("People").child("Accepted").child(yourID).exists()) {
                        if(snapshot.child("List Name").exists()){
                            //if(snapshot.child("Online").exists() && snapshot.child("Online").getValue().equals(true)) {
                            if(snapshot.child("Online").exists() && snapshot.child("Online").hasChildren() && snapshot.child("List Name Online").exists()) {
                                list.add(snapshot.child("List Name Online").getValue().toString());
                            } else {
                                list.add(snapshot.child("List Name").getValue().toString());
                            }
                        }
                    }
                }
                adapter.notifyDataSetChanged();
            }
            @Override
            public void onCancelled(@NonNull DatabaseError error) {
            }
        });

        //Short Click to delete list
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                Intent x = new Intent(MainActivity.this, TheList.class);
                if(list.get(i).contains(" (USER AT STORE!)")){
                    x.putExtra("data", list.get(i).replace(" (USER AT STORE!)", ""));
                } else {
                    x.putExtra("data", list.get(i));
                }
                startActivity(x);
            }
        });

        //Long Click to delete list
        listView.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> adapterView, View view, int i, long l) {
                AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);
                builder.setMessage("Delete this list?").setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int x) {
                        DatabaseReference reference = FirebaseDatabase.getInstance().getReference();
                        Toast.makeText(MainActivity.this, list.get(i), Toast.LENGTH_SHORT).show();
                        FirebaseDatabase.getInstance().getReference().addListenerForSingleValueEvent(new ValueEventListener() {
                            @Override
                            public void onDataChange(@NonNull DataSnapshot snapshot) {
                                if(snapshot.child("Lists").child(list.get(i).replace(" (USER AT STORE!)", "")).child("Online").hasChild(yourID)){
                                    reference.child("Lists").child(list.get(i).replace(" (USER AT STORE!)", "")).child("Online").child(yourID).removeValue();
                                }
                                reference.child("Users").child(yourID).child("History").child(list.get(i).replace(" (USER AT STORE!)", "")).setValue(
                                        snapshot.child("Lists").child(list.get(i).replace(" (USER AT STORE!)", "")).child("uniqueID").getValue().toString());
                                reference.child("Lists").child(list.get(i).replace(" (USER AT STORE!)", "")).child("People").child("Accepted").child(yourID).removeValue();
                            }

                            @Override
                            public void onCancelled(@NonNull DatabaseError error) {

                            }
                        });

                    }
                }).setNegativeButton("No", null);
                AlertDialog alert = builder.create();
                alert.show();
                return true;
            }
        });
    }

    //onclicklistener for a user to create a new list
    public void openCreateListActivity() {
        Intent intent = new Intent(this, CreateListActivity.class);
        startActivity(intent);
    }

    //onclicklistener for a user to enter a specific list's page
    private void setUpListViewListener() {
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                startActivity(new Intent(MainActivity.this, TheList.class));
                finish();
            }
        });
    }

    //checks the user's pending invites
    //allows a user to deny or accept any invites received
    //if accepted, user becomes part of the invited list on firebase and updated via firebase
    public void checkInvites(){
        dialogBuilder = new AlertDialog.Builder(this);
        final View userView = getLayoutInflater().inflate(R.layout.invite_popup, null);
        cancel = (Button) userView.findViewById(R.id.cancelButton);
        accept = (Button) userView.findViewById(R.id.accept);
        list = (ListView) userView.findViewById(R.id.inviteList);
        dialogBuilder.setView(userView);
        dialog = dialogBuilder.create();
        dialog.show();

        HashMap<String, Object> List1 = new HashMap<>();

        ArrayList<String> inviteList = new ArrayList<>();
        ArrayAdapter adapter = new ArrayAdapter<String>(this,android.R.layout.simple_list_item_multiple_choice, inviteList);
        list.setAdapter(adapter);

        DatabaseReference ref = FirebaseDatabase.getInstance().getReference();
        DatabaseReference ref2 = ref.child("Users").child(FirebaseAuth.getInstance().getCurrentUser().getUid()).child("Pending");
        ref2.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                for (DataSnapshot snapshot2 : snapshot.getChildren()) {
                    if(snapshot2.exists()){
                        inviteList.add(snapshot2.getValue().toString());
                    }
                }
                adapter.notifyDataSetChanged();
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });
        accept.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                SparseBooleanArray checked = list.getCheckedItemPositions();
                itemCount = list.getCount();
                for(w = itemCount - 1; w >= 0; w--){
                    if(checked.get(w)){
                        String checkedInvite = inviteList.get(w);
                        adapter.remove(checkedInvite);
                        DatabaseReference ref2 = FirebaseDatabase.getInstance().getReference();
                        ref2.child("Lists").child(checkedInvite).child("People").child("Accepted").addListenerForSingleValueEvent(new ValueEventListener() {
                            @Override
                            public void onDataChange(@NonNull DataSnapshot snapshot) {
                                i = (int)snapshot.getChildrenCount();
                                List1.put(FirebaseAuth.getInstance().getCurrentUser().getUid(), "Person " + i);
                                FirebaseDatabase.getInstance().getReference("Lists").child(checkedInvite).child("People").child("Accepted").updateChildren(List1);
                                FirebaseDatabase.getInstance().getReference("Lists").child(checkedInvite).child("People").child("Pending").child(FirebaseAuth.getInstance().getCurrentUser().getUid()).removeValue();
                                FirebaseDatabase.getInstance().getReference().child("Users").child(FirebaseAuth.getInstance().getUid()).child("Pending").addValueEventListener(new ValueEventListener() {
                                    @Override
                                    public void onDataChange(@NonNull DataSnapshot snapshot) {
                                        for(DataSnapshot snap: snapshot.getChildren()){
                                            if(snap.exists()){
                                                if(snap.getValue().toString().equals(checkedInvite)){
                                                    snap.getRef().removeValue();
                                                }
                                            }
                                        }
                                    }
                                    @Override
                                    public void onCancelled(@NonNull DatabaseError error) {
                                    }
                                });
                            }
                            @Override
                            public void onCancelled(@NonNull DatabaseError error) {
                            }
                        });
                        adapter.notifyDataSetChanged();
                    }
                }
                list.clearChoices();
            }
        });
        cancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                dialog.dismiss();
            }
        });
    }
}