package com.example.groceryapp;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;

import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.drawable.AnimationDrawable;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.Checkable;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Toast;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;


import com.google.firebase.database.FirebaseDatabase;

import io.paperdb.Paper;

public class StartActivity extends AppCompatActivity {

    ConstraintLayout nLayout;
    AnimationDrawable nDrawable;

    private Button register;
    private Button login;
    private EditText email;
    private EditText password;
    private CheckBox rememberMe;
    private FirebaseAuth auth;
    private static final String UserEmailKey = "UserEmail";
    private static final String UserPasswordKey = "UserPassword";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_start);

        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN);

        nLayout = (ConstraintLayout) findViewById(R.id.layout);
        nDrawable = (AnimationDrawable) nLayout.getBackground();
        nDrawable.setEnterFadeDuration(3000);
        nDrawable.setExitFadeDuration(3000);
        nDrawable.start();

        register =findViewById(R.id.register);
        login = findViewById(R.id.login);

        email =findViewById(R.id.email);
        password =findViewById(R.id.password);
        login =findViewById(R.id.login);
        rememberMe = findViewById(R.id.rememberMe);

        Paper.init(StartActivity.this);

        auth = FirebaseAuth.getInstance();

        String UserEmail = Paper.book().read(UserEmailKey);
        String UserPassword = Paper.book().read(UserPasswordKey);
        if(UserEmail != "" && UserPassword != ""){
            if(!TextUtils.isEmpty(UserEmail) && !TextUtils.isEmpty(UserPassword)){
                loginUser(UserEmail, UserPassword);
            }
        }

        login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String txt_email = email.getText().toString();
                String txt_password = password.getText().toString();
                loginUser(txt_email, txt_password);
            }
        });

        register.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(StartActivity.this, RegisterActivity.class));
                finish();
            }
        });

    }
    private void loginUser(String email, String password) {

        if(rememberMe.isChecked()){
            Paper.book().write(UserEmailKey, email);
            Paper.book().write(UserPasswordKey, password);
        }

        auth.signInWithEmailAndPassword(email, password).addOnSuccessListener(new OnSuccessListener<AuthResult>() {
            @Override
            public void onSuccess(AuthResult authResult) {
                Toast.makeText(StartActivity.this, "Login successful!", Toast.LENGTH_SHORT).show();
                String userEmail = auth.getCurrentUser().getUid();
                Intent i = new Intent(StartActivity.this, MainActivity.class);
                i.putExtra("email", userEmail);
                startActivity(i);
                finish();
            }
        });
        auth.signInWithEmailAndPassword(email, password).addOnFailureListener(new OnFailureListener() {
            @Override
            public void onFailure(@NonNull Exception e) {
                Toast.makeText(StartActivity.this, "Incorrect email or password. Please try again.", Toast.LENGTH_SHORT).show();
            }
        });
    }

}