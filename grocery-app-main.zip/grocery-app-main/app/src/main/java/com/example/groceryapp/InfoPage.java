package com.example.groceryapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;

import java.util.ArrayList;

public class InfoPage extends AppCompatActivity {

    private ListView help;
    private Button back;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_info_page);

        help = findViewById(R.id.helpList);
        back = findViewById(R.id.back);

        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(InfoPage.this, MainActivity.class));
            }
        });

        ArrayList<String> list = new ArrayList<>();
        ArrayAdapter adapter = new ArrayAdapter<String>(this,android.R.layout.simple_list_item_1, list);
        help.setAdapter(adapter);

        list.add("How to Create a List (and from History)");
        list.add("How to Enter/Delete a List");
        list.add("How to be invited to another List");
        list.add("How to add Users to a current List");
        list.add("How to use a List");

        adapter.notifyDataSetChanged();

        help.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                Intent x = new Intent(InfoPage.this, TheInfo.class);
                x.putExtra("tut", i);
                startActivity(x);
            }
        });

    }
}