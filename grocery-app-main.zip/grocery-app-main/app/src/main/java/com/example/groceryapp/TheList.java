package com.example.groceryapp;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Paint;
import android.hardware.SensorEventListener2;
import android.os.Bundle;
import android.util.SparseBooleanArray;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.EditorInfo;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.HashMap;

import io.paperdb.Paper;

public class TheList extends AppCompatActivity {

    private String theList, personName, userID, lowerCase, noCheck, itemPrice, checker;
    private ListView itemList, sharedPeople, listPrice;
    private int index, s = 0, i, w, x, t = 0, itemCount;
    private ImageView invite;
    private AlertDialog.Builder dialogBuilder;
    private AlertDialog dialog;
    private TextView priceText;
    private EditText uid, price;
    private Button add, cancel, deleteItems, checkOffBtn, priceCheckButton, close;
    private String checkedMark = "\u2713";
    private Integer[] imageid;
    private Double total = 0.00;
    private ArrayList<String> peopleArr = new ArrayList<String>();
    private ArrayList<String> peopleID = new ArrayList<String>();
    SparseBooleanArray mCheckStates;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_the_list);
        itemList = findViewById(R.id.itemList);
        invite = findViewById(R.id.addPerson);
        deleteItems = findViewById(R.id.deleteItems);
        checkOffBtn = findViewById(R.id.checkOff);
        sharedPeople = findViewById(R.id.people);
        priceText = findViewById(R.id.priceText);
        priceCheckButton = findViewById(R.id.checkPrice);

        Intent i = getIntent();
        String data = i.getStringExtra("data");

        TextView name = (TextView)findViewById(R.id.listName);
        name.setText(data);

        ArrayAdapter peopleAdap = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, peopleArr);
        sharedPeople.setAdapter(peopleAdap);

        // Show people in the same list
        DatabaseReference peopleRef = FirebaseDatabase.getInstance().getReference();
        DatabaseReference pplRef = peopleRef.child("Lists").child(data).child("People").child("Accepted");
        pplRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                if(peopleArr.size() >= 1){
                    t = 0;
                    peopleID.clear();
                    peopleID.clear();
                    peopleArr.clear();
                    peopleAdap.clear();
                }
                for(DataSnapshot snapshot1 : snapshot.getChildren()){
                    userID = snapshot1.getRef().getKey();
                    peopleID.add(t, userID);
                    t++;
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });

        DatabaseReference peopleList = FirebaseDatabase.getInstance().getReference();
        DatabaseReference peopleList2 = peopleList.child("Users");
        peopleList2.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                for(int i = 0; i < peopleID.size(); i++){
                    String name = snapshot.child(peopleID.get(i)).child("name").getValue().toString();
                    peopleArr.add(name);
                }
                peopleAdap.notifyDataSetChanged();
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });


        ArrayList<String> eventList = new ArrayList<String>();
        ArrayAdapter adapt = new ArrayAdapter<String>(this,android.R.layout.simple_list_item_multiple_choice, eventList);
        itemList.setAdapter(adapt);

        itemList.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> adapterView, View view, int i, long l) {
                Intent intent = new Intent(TheList.this, barcode_scan.class);
                startActivity(intent);
                return false;
            }
        });

        // Show list of items
        DatabaseReference reference = FirebaseDatabase.getInstance().getReference();
        DatabaseReference listName = reference.child("Lists").child(data).child("items");
        listName.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if(dataSnapshot.exists())
                    eventList.clear();
                for (DataSnapshot snapshot : dataSnapshot.getChildren()) {
                    eventList.add(snapshot.getValue().toString());
                }
                adapt.notifyDataSetChanged();
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });

        // Show total price
        DatabaseReference reference2 = FirebaseDatabase.getInstance().getReference();
        DatabaseReference prices = reference.child("Lists").child(data).child("prices");
        prices.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                for (DataSnapshot snapshot2 : snapshot.getChildren()) {
                    total += Double.parseDouble(snapshot2.getValue().toString());
                }
                priceText.setText("$" + String.format("%.2f", total));
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });

        // Add price to items
        itemList.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> adapterView, View view, int i, long l) {
                dialogBuilder = new AlertDialog.Builder(TheList.this);
                final View userView = getLayoutInflater().inflate(R.layout.add_price_popup, null);
                price = (EditText) userView.findViewById(R.id.price);
                add = (Button) userView.findViewById(R.id.addPriceButton);
                cancel = (Button) userView.findViewById(R.id.cancel);
                dialogBuilder.setView(userView);
                dialog = dialogBuilder.create();
                dialog.show();

                String nameOfItem = eventList.get(i);
                String nameCheck = nameOfItem.substring(nameOfItem.length() - 1);
                if(nameCheck.equals(checkedMark)){
                    noCheck = nameOfItem.substring(0, nameOfItem.length() - 2);
                }
                else{
                    noCheck = nameOfItem;
                }

                add.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        String priceOfItem = price.getText().toString();
                        FirebaseDatabase.getInstance().getReference().child("Lists").child(data).child("prices").child(noCheck).setValue(priceOfItem);
                        total = 0.0;
                        dialog.dismiss();
                    }
                });

                cancel.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        dialog.dismiss();
                    }
                });

                return true;
            }
        });

        invite.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                addUser();
            }
        });

        deleteItems.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                SparseBooleanArray checked = itemList.getCheckedItemPositions();
                itemCount = itemList.getCount();
                for(w = itemCount - 1; w >= 0; w--){
                    if(checked.get(w)){
                        String itemToDelete = eventList.get(w);
                        if(itemToDelete.contains(checkedMark)){
                            checker = itemToDelete.substring(0, itemToDelete.length() - 2);
                        }
                        else{
                            checker = itemToDelete;
                        }
                        adapt.remove(itemToDelete);
                        DatabaseReference ref = FirebaseDatabase.getInstance().getReference().child("Lists").child(data).child("items").child(itemToDelete);
                        ref.removeValue();
                        DatabaseReference ref2 = FirebaseDatabase.getInstance().getReference().child("Lists").child(data).child("prices").child(checker);
                        ref2.removeValue();
                        total = 0.0;
                        adapt.notifyDataSetChanged();
                    }
                }
                itemList.clearChoices();
                itemCount = itemList.getCount();
                if(itemCount < 1){
                    finish();
                    startActivity(getIntent());
                }
            }
        });

        ArrayList<String> priceListAd = new ArrayList<>();
        ArrayAdapter adapterPrice = new ArrayAdapter<String>(this,android.R.layout.simple_list_item_1, priceListAd);


        // Check price of item
        priceCheckButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                dialogBuilder = new AlertDialog.Builder(TheList.this);
                final View userView = getLayoutInflater().inflate(R.layout.price_popup, null);
                close = (Button) userView.findViewById(R.id.priceClose);
                listPrice = (ListView) userView.findViewById(R.id.priceList);
                listPrice.setAdapter(adapterPrice);
                SparseBooleanArray checked = itemList.getCheckedItemPositions();
                itemCount = itemList.getCount();
                for(w = itemCount - 1; w >= 0; w--){
                    if(checked.get(w)){
                        String itemToCheck = eventList.get(w);
                        String nameCheck = itemToCheck.substring(itemToCheck.length() - 1);
                        if(nameCheck.equals(checkedMark)){
                            noCheck = itemToCheck.substring(0, itemToCheck.length() - 2);
                        }
                        else{
                            noCheck = itemToCheck;
                        }
                        DatabaseReference ref = FirebaseDatabase.getInstance().getReference().child("Lists").child(data).child("prices").child(noCheck);
                        ref.addValueEventListener(new ValueEventListener() {
                            @Override
                            public void onDataChange(@NonNull DataSnapshot snapshot) {
                                itemPrice = snapshot.getValue().toString();
                                String nameIt = snapshot.getKey().toString();
                                priceListAd.add(nameIt + "     $" + itemPrice);
                                adapterPrice.notifyDataSetChanged();
                            }

                            @Override
                            public void onCancelled(@NonNull DatabaseError error) {

                            }
                        });
                    }
                }
                priceListAd.clear();
                dialogBuilder.setView(userView);
                dialog = dialogBuilder.create();
                dialog.show();
                close.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        dialog.dismiss();
                    }
                });
            }
        });

        checkOffBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                SparseBooleanArray checked = itemList.getCheckedItemPositions();
                itemCount = itemList.getCount();
                for(w = itemCount - 1; w >= 0; w--){
                    if(checked.get(w)){
                        String itemToCheck = eventList.get(w);
                        DatabaseReference ref = FirebaseDatabase.getInstance().getReference().child("Lists").child(data).child("items").child(itemToCheck);
                        ref.addListenerForSingleValueEvent(new ValueEventListener() {
                            @Override
                            public void onDataChange(@NonNull DataSnapshot snapshot) {
                                String item = snapshot.getValue().toString();
                                String checkMark = item.substring(item.length() - 1);
                                if(!checkMark.equals(checkedMark)){
                                    ref.removeValue();
                                    adapt.remove(itemToCheck);
                                    adapt.add(itemToCheck + " " + checkedMark);
                                    FirebaseDatabase.getInstance().getReference().child("Lists").child(data).child("items").child(itemToCheck + " " + checkedMark).setValue(itemToCheck + " " + checkedMark);
                                    adapt.notifyDataSetChanged();
                                }else{
                                    ref.removeValue();
                                    adapt.remove(itemToCheck);
                                    String noCheck = itemToCheck.substring(0, itemToCheck.length() - 2);
                                    adapt.add(noCheck);
                                    FirebaseDatabase.getInstance().getReference().child("Lists").child(data).child("items").child(noCheck).setValue(noCheck);
                                    adapt.notifyDataSetChanged();
                                }
                            }

                            @Override
                            public void onCancelled(@NonNull DatabaseError error) {

                            }
                        });

                    }
                }
                itemList.clearChoices();
            }
        });

        EditText editText = (EditText) findViewById(R.id.addItem);
        editText.setOnEditorActionListener(new TextView.OnEditorActionListener() {
            @Override
            public boolean onEditorAction(TextView textView, int i, KeyEvent keyEvent) {
                if (i == EditorInfo.IME_ACTION_GO){
                    lowerCase = editText.getText().toString();
                    theList = lowerCase.substring(0,1).toUpperCase() + lowerCase.substring(1);
                    if(eventList.contains(theList)){
                        editText.getText().clear();
                        Toast.makeText(TheList.this, "Item already in list", Toast.LENGTH_SHORT).show();
                    }
                    FirebaseDatabase.getInstance().getReference().child("Lists").child(data).child("items").child(theList).setValue(theList);
                    FirebaseDatabase.getInstance().getReference().child("Lists").child(data).child("prices").child(theList).setValue("0");
                    editText.getText().clear();
                    DatabaseReference reference = FirebaseDatabase.getInstance().getReference();
                    DatabaseReference listName = reference.child("Lists").child(data).child("items");
                    listName.addValueEventListener(new ValueEventListener() {
                        @Override
                        public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                            if(dataSnapshot.exists())
                                eventList.clear();
                            for (DataSnapshot snapshot : dataSnapshot.getChildren()) {
                                eventList.add(snapshot.getValue().toString());
                            }
                            adapt.notifyDataSetChanged();
                        }

                        @Override
                        public void onCancelled(@NonNull DatabaseError error) {

                        }
                    });

                    return true;
                }
                return false;
            }
        });
    }

    public void addUser(){
        dialogBuilder = new AlertDialog.Builder(this);
        final View userView = getLayoutInflater().inflate(R.layout.popup, null);
        uid = (EditText) userView.findViewById(R.id.uid);
        add = (Button) userView.findViewById(R.id.add);
        cancel = (Button) userView.findViewById(R.id.cancel);
        dialogBuilder.setView(userView);
        dialog = dialogBuilder.create();
        dialog.show();

        HashMap<String, Object> List1 = new HashMap<>();
        String data = getIntent().getStringExtra("data");

        add.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String thePerson = uid.getText().toString();
                FirebaseDatabase.getInstance().getReference("Users").addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot snapshot) {
                        if(snapshot.child(thePerson).child("Pending").child(data).exists() || thePerson.equals(FirebaseAuth.getInstance().getCurrentUser().getUid())){
                            uid.getText().clear();
                            Toast.makeText(TheList.this, "User is already added!", Toast.LENGTH_SHORT).show();
                        }
                        else if(snapshot.hasChild(thePerson) && thePerson.isEmpty() == false){
                            DatabaseReference ref = FirebaseDatabase.getInstance().getReference();
                            ref.child("Lists").child(data).child("People").child("Pending").addListenerForSingleValueEvent(new ValueEventListener() {
                                @Override
                                public void onDataChange(@NonNull DataSnapshot snapshot) {
                                    i = (int)snapshot.getChildrenCount();
                                    i++;
                                    List1.put(thePerson, "Person " + i);
                                    FirebaseDatabase.getInstance().getReference("Lists").child(data).child("People").child("Pending").updateChildren(List1);
                                }

                                @Override
                                public void onCancelled(@NonNull DatabaseError error) {

                                }
                            });
                            DatabaseReference ref2 = FirebaseDatabase.getInstance().getReference();
                            ref2.child("Lists").child(data).child("uniqueID").addListenerForSingleValueEvent(new ValueEventListener() {
                                @Override
                                public void onDataChange(@NonNull DataSnapshot snapshot) {
                                    String listID = snapshot.getValue().toString();
                                    FirebaseDatabase.getInstance().getReference().child("Users").child(thePerson).child("Pending").child(listID).setValue(data);
                                }

                                @Override
                                public void onCancelled(@NonNull DatabaseError error) {

                                }
                            });
                            FirebaseDatabase.getInstance().getReference("Users").addListenerForSingleValueEvent(new ValueEventListener() {
                                @Override
                                public void onDataChange(@NonNull DataSnapshot snapshot) {
                                    String personName = snapshot.child(thePerson).child("name").getValue().toString();
                                    Toast.makeText(TheList.this,  personName + " has been added.", Toast.LENGTH_SHORT).show();
                                }

                                @Override
                                public void onCancelled(@NonNull DatabaseError error) {

                                }
                            });
                            uid.getText().clear();
                        }
                        else{
                            uid.getText().clear();
                            Toast.makeText(TheList.this, "User does not exist!", Toast.LENGTH_SHORT).show();
                        }

                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError error) {

                    }
                });
            }
        });


        cancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                dialog.dismiss();
            }
        });
    }
}
