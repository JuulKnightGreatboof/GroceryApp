package com.example.groceryapp;

import androidx.appcompat.app.AppCompatActivity;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.widget.ImageView;

import com.airbnb.lottie.LottieAnimationView;

public class IntroActivity extends AppCompatActivity {

    ImageView logo, appName, splashImg;
    LottieAnimationView lottieAnimationView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_intro);

        appName = findViewById(R.id.name);
        splashImg = findViewById(R.id.img);
        lottieAnimationView = findViewById(R.id.logo);

        lottieAnimationView.addAnimatorListener(new AnimatorListenerAdapter() {
            @Override
            public void onAnimationCancel(Animator animation) {

            }

            @Override
            public void onAnimationEnd(Animator animation) {
                final Handler handler = new Handler(Looper.getMainLooper());
                handler.postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        Intent i = new Intent(IntroActivity.this, StartActivity.class);
                        startActivity(i);
                    }
                }, 2650);
            }

            @Override
            public void onAnimationRepeat(Animator animation) {

            }

            @Override
            public void onAnimationStart(Animator animation) {
                splashImg.animate().translationY(-3000).setDuration(1000).setStartDelay(4000);
                appName.animate().translationY(1400).setDuration(1000).setStartDelay(4000);
                lottieAnimationView.animate().translationY(1400).setDuration(1000).setStartDelay(4000);
            }
        });

    }
}