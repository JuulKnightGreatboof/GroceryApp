package com.example.groceryapp;

public class Item {
    //private member variables
    private String itemName;
    private boolean bought;

    //constructor
    public Item(String n) {
        itemName = n;
        bought = false;
    }

    //getter and setter methods
    public String getItemName() {
        return itemName;
    }
    public boolean isBought() {
        return bought;
    }
    public void setAsBought() {
        bought = true;
    }
}
